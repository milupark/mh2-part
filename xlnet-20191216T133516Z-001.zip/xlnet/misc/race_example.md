## A RACE Exampple

**Paragraph**

It was a cold night. The taxi driver didn't take even one passenger all day.
When he went by the railway station, he saw a young man coming out with two bags in his hands.
So he drove to him and asked, " where are you going, sir?"
"To the Red Hotel," the young man answered.
When the taxi driver heard this, he didn't feel happy any more.
The young man would give him only three dollars because the hotel was near the railway station.
But suddenly, he had an idea. He took the young man through many streets of the big city.
After a long time, they arrived at the hotel. "Here we are! You should pay me fifteen dollars, please." the taxi driver said to the young man."
What? Fifteen dollars! Do you think I'm a fool? Only last week, I took a taxi from the railway station to this hotel and I only gave the driver thirteen dollars.
I know how much I have to pay for the trip."

**Question 1**

Maybe the taxi driver got _ dollars at last.

**Answer Candidates**

- 3
- 2
- 13
- 15

**Question 2**

Which of the following is TRUE?

**Answer Candidates**

- The two taxi drivers were both honest.
- The two taxi drivers cheated the young man.
- It is very far from the railway station to the Red Hotel.
- The young man knew how far it was from the railway station to the hotel.
